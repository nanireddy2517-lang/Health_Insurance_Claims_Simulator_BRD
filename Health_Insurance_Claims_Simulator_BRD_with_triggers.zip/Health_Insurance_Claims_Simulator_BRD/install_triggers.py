"""Install / refresh the MySQL history triggers on an existing database.

Usage:  python install_triggers.py
(No data is changed; safe to re-run.)
"""
from app import create_app
from app.extensions import db
from app.services.db_triggers import install_triggers

app = create_app()
with app.app_context():
    db.create_all()  # make sure claim_audit_log exists
    n = install_triggers()
    print(f"Installed audit triggers ({n} statements executed).")
