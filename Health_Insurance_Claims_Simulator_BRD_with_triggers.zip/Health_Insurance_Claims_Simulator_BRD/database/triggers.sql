-- =============================================================================
-- Health Insurance Claims Simulator — History / Audit Triggers
-- Database: MySQL 8.0+
--
-- Maintains a row-level change history in `claim_audit_log` for:
--   * claims           (INSERT / UPDATE / DELETE)
--   * claim_documents  (INSERT / UPDATE / DELETE)
--   * settlements      (INSERT / UPDATE / DELETE)
--
-- This is separate from `claim_history` (the workflow/status timeline written
-- by the app). The triggers capture EVERY data change, even ones made directly
-- in SQL, with old/new values and the list of columns that changed.
--
-- Safe to re-run: every trigger is dropped and recreated.
-- Run:  mysql -u root -p health_claims_simulator < database/triggers.sql
-- =============================================================================

USE `health_claims_simulator`;

CREATE TABLE IF NOT EXISTS `claim_audit_log` (
    `id`             BIGINT AUTO_INCREMENT PRIMARY KEY,
    `table_name`     VARCHAR(50)  NOT NULL,
    `record_id`      INT          NOT NULL,
    `claim_id`       INT          NULL,
    `action`         VARCHAR(10)  NOT NULL,              -- INSERT / UPDATE / DELETE
    `changed_fields` JSON         NULL,                  -- e.g. ["status","eligible_amount_inr"]
    `old_values`     JSON         NULL,
    `new_values`     JSON         NULL,
    `db_user`        VARCHAR(100) NOT NULL,
    `changed_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_audit_claim_time`  (`claim_id`, `changed_at`),
    INDEX `idx_audit_table_record` (`table_name`, `record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- NOTE: no foreign keys on purpose, so history survives deletion of the claim.

DELIMITER $$

-- =============================================================================
-- CLAIMS
-- =============================================================================
DROP TRIGGER IF EXISTS `trg_claims_ai`$$
CREATE TRIGGER `trg_claims_ai` AFTER INSERT ON `claims`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, new_values, db_user)
    VALUES ('claims', NEW.id, NEW.id, 'INSERT',
        JSON_OBJECT(
            'policy_id', NEW.policy_id, 'member_id', NEW.member_id,
            'hospital_id', NEW.hospital_id, 'claim_type', NEW.claim_type,
            'treatment_type', NEW.treatment_type,
            'admission_date', NEW.admission_date, 'discharge_date', NEW.discharge_date,
            'requested_amount_inr', NEW.requested_amount_inr, 'status', NEW.status,
            'eligible_amount_inr', NEW.eligible_amount_inr,
            'officer_user_id', NEW.officer_user_id,
            'payment_recorded_date', NEW.payment_recorded_date
        ),
        CURRENT_USER());
END$$

DROP TRIGGER IF EXISTS `trg_claims_au`$$
CREATE TRIGGER `trg_claims_au` AFTER UPDATE ON `claims`
FOR EACH ROW
BEGIN
    DECLARE v_changed JSON DEFAULT JSON_ARRAY();

    IF NOT (OLD.policy_id <=> NEW.policy_id) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'policy_id'); END IF;
    IF NOT (OLD.member_id <=> NEW.member_id) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'member_id'); END IF;
    IF NOT (OLD.hospital_id <=> NEW.hospital_id) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'hospital_id'); END IF;
    IF NOT (OLD.claim_type <=> NEW.claim_type) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'claim_type'); END IF;
    IF NOT (OLD.treatment_type <=> NEW.treatment_type) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'treatment_type'); END IF;
    IF NOT (OLD.admission_date <=> NEW.admission_date) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'admission_date'); END IF;
    IF NOT (OLD.discharge_date <=> NEW.discharge_date) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'discharge_date'); END IF;
    IF NOT (OLD.requested_amount_inr <=> NEW.requested_amount_inr) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'requested_amount_inr'); END IF;
    IF NOT (OLD.status <=> NEW.status) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'status'); END IF;
    IF NOT (OLD.eligible_amount_inr <=> NEW.eligible_amount_inr) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'eligible_amount_inr'); END IF;
    IF NOT (OLD.officer_user_id <=> NEW.officer_user_id) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'officer_user_id'); END IF;
    IF NOT (OLD.payment_recorded_date <=> NEW.payment_recorded_date) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'payment_recorded_date'); END IF;

    -- Skip no-op updates (updated_at alone is not a business change)
    IF JSON_LENGTH(v_changed) > 0 THEN
        INSERT INTO claim_audit_log
            (table_name, record_id, claim_id, action, changed_fields, old_values, new_values, db_user)
        VALUES ('claims', NEW.id, NEW.id, 'UPDATE', v_changed,
            JSON_OBJECT(
                'policy_id', OLD.policy_id, 'member_id', OLD.member_id,
                'hospital_id', OLD.hospital_id, 'claim_type', OLD.claim_type,
                'treatment_type', OLD.treatment_type,
                'admission_date', OLD.admission_date, 'discharge_date', OLD.discharge_date,
                'requested_amount_inr', OLD.requested_amount_inr, 'status', OLD.status,
                'eligible_amount_inr', OLD.eligible_amount_inr,
                'officer_user_id', OLD.officer_user_id,
                'payment_recorded_date', OLD.payment_recorded_date
            ),
            JSON_OBJECT(
                'policy_id', NEW.policy_id, 'member_id', NEW.member_id,
                'hospital_id', NEW.hospital_id, 'claim_type', NEW.claim_type,
                'treatment_type', NEW.treatment_type,
                'admission_date', NEW.admission_date, 'discharge_date', NEW.discharge_date,
                'requested_amount_inr', NEW.requested_amount_inr, 'status', NEW.status,
                'eligible_amount_inr', NEW.eligible_amount_inr,
                'officer_user_id', NEW.officer_user_id,
                'payment_recorded_date', NEW.payment_recorded_date
            ),
            CURRENT_USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS `trg_claims_ad`$$
CREATE TRIGGER `trg_claims_ad` AFTER DELETE ON `claims`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, old_values, db_user)
    VALUES ('claims', OLD.id, OLD.id, 'DELETE',
        JSON_OBJECT(
            'policy_id', OLD.policy_id, 'member_id', OLD.member_id,
            'hospital_id', OLD.hospital_id, 'claim_type', OLD.claim_type,
            'treatment_type', OLD.treatment_type,
            'admission_date', OLD.admission_date, 'discharge_date', OLD.discharge_date,
            'requested_amount_inr', OLD.requested_amount_inr, 'status', OLD.status,
            'eligible_amount_inr', OLD.eligible_amount_inr,
            'officer_user_id', OLD.officer_user_id,
            'payment_recorded_date', OLD.payment_recorded_date
        ),
        CURRENT_USER());
END$$

-- =============================================================================
-- CLAIM_DOCUMENTS
-- =============================================================================
DROP TRIGGER IF EXISTS `trg_claim_documents_ai`$$
CREATE TRIGGER `trg_claim_documents_ai` AFTER INSERT ON `claim_documents`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, new_values, db_user)
    VALUES ('claim_documents', NEW.id, NEW.claim_id, 'INSERT',
        JSON_OBJECT(
            'document_type', NEW.document_type, 'checklist_status', NEW.checklist_status,
            'original_filename', NEW.original_filename, 'stored_filename', NEW.stored_filename,
            'uploaded_at', NEW.uploaded_at
        ),
        CURRENT_USER());
END$$

DROP TRIGGER IF EXISTS `trg_claim_documents_au`$$
CREATE TRIGGER `trg_claim_documents_au` AFTER UPDATE ON `claim_documents`
FOR EACH ROW
BEGIN
    DECLARE v_changed JSON DEFAULT JSON_ARRAY();

    IF NOT (OLD.document_type <=> NEW.document_type) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'document_type'); END IF;
    IF NOT (OLD.checklist_status <=> NEW.checklist_status) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'checklist_status'); END IF;
    IF NOT (OLD.original_filename <=> NEW.original_filename) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'original_filename'); END IF;
    IF NOT (OLD.stored_filename <=> NEW.stored_filename) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'stored_filename'); END IF;
    IF NOT (OLD.uploaded_at <=> NEW.uploaded_at) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'uploaded_at'); END IF;

    IF JSON_LENGTH(v_changed) > 0 THEN
        INSERT INTO claim_audit_log
            (table_name, record_id, claim_id, action, changed_fields, old_values, new_values, db_user)
        VALUES ('claim_documents', NEW.id, NEW.claim_id, 'UPDATE', v_changed,
            JSON_OBJECT(
                'document_type', OLD.document_type, 'checklist_status', OLD.checklist_status,
                'original_filename', OLD.original_filename, 'stored_filename', OLD.stored_filename,
                'uploaded_at', OLD.uploaded_at
            ),
            JSON_OBJECT(
                'document_type', NEW.document_type, 'checklist_status', NEW.checklist_status,
                'original_filename', NEW.original_filename, 'stored_filename', NEW.stored_filename,
                'uploaded_at', NEW.uploaded_at
            ),
            CURRENT_USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS `trg_claim_documents_ad`$$
CREATE TRIGGER `trg_claim_documents_ad` AFTER DELETE ON `claim_documents`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, old_values, db_user)
    VALUES ('claim_documents', OLD.id, OLD.claim_id, 'DELETE',
        JSON_OBJECT(
            'document_type', OLD.document_type, 'checklist_status', OLD.checklist_status,
            'original_filename', OLD.original_filename, 'stored_filename', OLD.stored_filename,
            'uploaded_at', OLD.uploaded_at
        ),
        CURRENT_USER());
END$$

-- =============================================================================
-- SETTLEMENTS
-- =============================================================================
DROP TRIGGER IF EXISTS `trg_settlements_ai`$$
CREATE TRIGGER `trg_settlements_ai` AFTER INSERT ON `settlements`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, new_values, db_user)
    VALUES ('settlements', NEW.id, NEW.claim_id, 'INSERT',
        JSON_OBJECT(
            'payee_type', NEW.payee_type, 'amount_inr', NEW.amount_inr,
            'recorded_by_user_id', NEW.recorded_by_user_id, 'recorded_date', NEW.recorded_date
        ),
        CURRENT_USER());
END$$

DROP TRIGGER IF EXISTS `trg_settlements_au`$$
CREATE TRIGGER `trg_settlements_au` AFTER UPDATE ON `settlements`
FOR EACH ROW
BEGIN
    DECLARE v_changed JSON DEFAULT JSON_ARRAY();

    IF NOT (OLD.payee_type <=> NEW.payee_type) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'payee_type'); END IF;
    IF NOT (OLD.amount_inr <=> NEW.amount_inr) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'amount_inr'); END IF;
    IF NOT (OLD.recorded_by_user_id <=> NEW.recorded_by_user_id) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'recorded_by_user_id'); END IF;
    IF NOT (OLD.recorded_date <=> NEW.recorded_date) THEN SET v_changed = JSON_ARRAY_APPEND(v_changed, '$', 'recorded_date'); END IF;

    IF JSON_LENGTH(v_changed) > 0 THEN
        INSERT INTO claim_audit_log
            (table_name, record_id, claim_id, action, changed_fields, old_values, new_values, db_user)
        VALUES ('settlements', NEW.id, NEW.claim_id, 'UPDATE', v_changed,
            JSON_OBJECT(
                'payee_type', OLD.payee_type, 'amount_inr', OLD.amount_inr,
                'recorded_by_user_id', OLD.recorded_by_user_id, 'recorded_date', OLD.recorded_date
            ),
            JSON_OBJECT(
                'payee_type', NEW.payee_type, 'amount_inr', NEW.amount_inr,
                'recorded_by_user_id', NEW.recorded_by_user_id, 'recorded_date', NEW.recorded_date
            ),
            CURRENT_USER());
    END IF;
END$$

DROP TRIGGER IF EXISTS `trg_settlements_ad`$$
CREATE TRIGGER `trg_settlements_ad` AFTER DELETE ON `settlements`
FOR EACH ROW
BEGIN
    INSERT INTO claim_audit_log (table_name, record_id, claim_id, action, old_values, db_user)
    VALUES ('settlements', OLD.id, OLD.claim_id, 'DELETE',
        JSON_OBJECT(
            'payee_type', OLD.payee_type, 'amount_inr', OLD.amount_inr,
            'recorded_by_user_id', OLD.recorded_by_user_id, 'recorded_date', OLD.recorded_date
        ),
        CURRENT_USER());
END$$

DELIMITER ;
