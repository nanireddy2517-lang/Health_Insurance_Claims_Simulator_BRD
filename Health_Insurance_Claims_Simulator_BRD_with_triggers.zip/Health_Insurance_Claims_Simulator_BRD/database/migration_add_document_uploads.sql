-- Run once on an EXISTING health_claims_simulator database (MySQL 8.0)
-- to add file-upload support to the document checklist.
-- Fresh installs using schema.sql already include these columns.
USE health_claims_simulator;

ALTER TABLE `claim_documents`
    ADD COLUMN `original_filename` VARCHAR(255) NULL AFTER `checklist_status`,
    ADD COLUMN `stored_filename`   VARCHAR(255) NULL AFTER `original_filename`,
    ADD COLUMN `uploaded_at`       DATETIME NULL AFTER `stored_filename`;
