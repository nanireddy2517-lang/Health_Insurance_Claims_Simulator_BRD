"""Reset every user's password to 'password123'.

Place this file in the project root (same folder as config.py) and run:
    python reset_passwords.py
"""
from werkzeug.security import generate_password_hash

from app import create_app
from app.extensions import db
from app.models import User

NEW_PASSWORD = "password123"

app = create_app()
with app.app_context():
    new_hash = generate_password_hash(NEW_PASSWORD)
    users = User.query.all()

    if not users:
        print("No users found in the users table. Import complete_practice_dataset.sql first.")
    else:
        for u in users:
            u.password_hash = new_hash
        db.session.commit()
        print(f"Reset {len(users)} users to password '{NEW_PASSWORD}':")
        for u in users:
            print(f" - {u.username} ({u.role})")
