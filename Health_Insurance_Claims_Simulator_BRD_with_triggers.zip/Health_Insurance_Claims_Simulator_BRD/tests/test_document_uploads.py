"""
Tests for the required document uploads (hospital bill + discharge summary).

Uses an in-memory SQLite database and a temp upload folder, so MySQL is not needed:
    python -m unittest tests.test_document_uploads
"""
import datetime
import io
import shutil
import tempfile
import unittest
from decimal import Decimal

from werkzeug.security import generate_password_hash

from app import create_app
from app.extensions import db
from app.models import Claim, ClaimDocument, Hospital, Member, Plan, Policy, User


class TestConfig:
    SECRET_KEY = "test"
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite://"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    ALLOWED_UPLOAD_EXTENSIONS = {"pdf", "jpg", "jpeg", "png"}
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024


def pdf(name="file.pdf", content=b"%PDF-1.4 test"):
    return (io.BytesIO(content), name)


class DocumentUploadTests(unittest.TestCase):
    def setUp(self):
        self.upload_dir = tempfile.mkdtemp()
        TestConfig.UPLOAD_FOLDER = self.upload_dir
        self.app = create_app(TestConfig)
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            h = Hospital(id=1, name="H1", city="C", network_status=True)
            plan = Plan(id=1, name="Essential", covered_treatment_types="inpatient",
                        annual_limit_inr=100000, deductible_inr=2000, copay_percent=10)
            owner = User(id=1, username="owner", password_hash=generate_password_hash("pw"),
                         display_name="Owner", role="policyholder")
            other = User(id=2, username="other", password_hash=generate_password_hash("pw"),
                         display_name="Other", role="policyholder")
            officer = User(id=3, username="officer", password_hash=generate_password_hash("pw"),
                           display_name="Officer", role="claims_officer")
            db.session.add_all([h, plan, owner, other, officer])
            db.session.flush()
            today = datetime.date.today()
            pol = Policy(id=101, holder_user_id=1, plan_id=1,
                         start_date=today - datetime.timedelta(days=100),
                         end_date=today + datetime.timedelta(days=200), status="active")
            db.session.add(pol)
            db.session.flush()
            db.session.add(Member(id=201, policy_id=101, display_name="Owner", relationship="self"))
            db.session.commit()
            self.today = today

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
        shutil.rmtree(self.upload_dir, ignore_errors=True)

    def login(self, user):
        self.client.post("/login", data={"username": user, "password": "pw"})

    def claim_form(self, action, **files):
        data = {
            "action": action, "policy_id": 101, "member_id": 201, "hospital_id": 1,
            "treatment_type": "inpatient",
            "admission_date": (self.today - datetime.timedelta(days=5)).isoformat(),
            "discharge_date": (self.today - datetime.timedelta(days=2)).isoformat(),
            "requested_amount": "15000", "description": "test",
        }
        data.update(files)
        return data

    def latest_claim(self):
        return Claim.query.order_by(Claim.id.desc()).first()

    def test_submit_requires_both_documents(self):
        self.login("owner")
        resp = self.client.post("/claims/new", data=self.claim_form("submit"),
                                content_type="multipart/form-data", follow_redirects=True)
        self.assertIn(b"Hospital bill is required", resp.data)
        self.assertIn(b"Discharge summary is required", resp.data)
        with self.app.app_context():
            self.assertEqual(Claim.query.count(), 0)

    def test_submit_with_only_one_document_is_blocked(self):
        self.login("owner")
        data = self.claim_form("submit", file_hospital_bill=pdf("bill.pdf"))
        resp = self.client.post("/claims/new", data=data, content_type="multipart/form-data",
                                follow_redirects=True)
        self.assertIn(b"Discharge summary is required", resp.data)
        with self.app.app_context():
            self.assertEqual(Claim.query.count(), 0)

    def test_submit_with_both_documents_stores_files(self):
        self.login("owner")
        data = self.claim_form("submit", file_hospital_bill=pdf("bill.pdf"),
                               file_discharge_summary=pdf("discharge.pdf"))
        self.client.post("/claims/new", data=data, content_type="multipart/form-data")
        with self.app.app_context():
            claim = self.latest_claim()
            self.assertEqual(claim.status, "submitted")
            docs = {d.document_type: d for d in claim.documents}
            self.assertEqual(set(docs), {"hospital_bill", "discharge_summary"})
            for d in docs.values():
                self.assertEqual(d.checklist_status, "received")
                self.assertTrue(d.has_file)
            self.assertEqual(docs["hospital_bill"].original_filename, "bill.pdf")
            doc_id = docs["hospital_bill"].id
            claim_id = claim.id
        # Owner can open the file; another policyholder cannot; officer can
        self.assertEqual(self.client.get(f"/claims/documents/{doc_id}/download").status_code, 200)
        self.client.get("/logout")
        self.login("other")
        self.assertEqual(self.client.get(f"/claims/documents/{doc_id}/download").status_code, 403)
        self.client.get("/logout")
        self.login("officer")
        self.assertEqual(self.client.get(f"/claims/documents/{doc_id}/download").status_code, 200)

    def test_bad_file_type_rejected(self):
        self.login("owner")
        data = self.claim_form("submit", file_hospital_bill=pdf("bill.exe"),
                               file_discharge_summary=pdf("d.pdf"))
        resp = self.client.post("/claims/new", data=data, content_type="multipart/form-data",
                                follow_redirects=True)
        self.assertIn(b"files are allowed", resp.data)
        with self.app.app_context():
            self.assertEqual(Claim.query.count(), 0)

    def test_draft_without_files_then_upload_then_submit(self):
        self.login("owner")
        self.client.post("/claims/new", data=self.claim_form("draft"), content_type="multipart/form-data")
        with self.app.app_context():
            claim = self.latest_claim()
            self.assertEqual(claim.status, "draft")
            self.assertTrue(all(d.checklist_status == "missing" for d in claim.documents))
            cid = claim.id
        # Submitting the draft with no documents is blocked
        resp = self.client.post(f"/claims/{cid}/submit", follow_redirects=True)
        self.assertIn(b"Upload the required documents", resp.data)
        # Upload only the bill -> still blocked on the discharge summary
        self.client.post(f"/claims/{cid}/documents", data={"file_hospital_bill": pdf("b.pdf")},
                         content_type="multipart/form-data")
        resp = self.client.post(f"/claims/{cid}/submit", follow_redirects=True)
        self.assertIn(b"Discharge summary", resp.data)
        with self.app.app_context():
            self.assertEqual(db.session.get(Claim, cid).status, "draft")
        # Upload the discharge summary -> submission succeeds
        self.client.post(f"/claims/{cid}/documents", data={"file_discharge_summary": pdf("d.pdf")},
                         content_type="multipart/form-data")
        self.client.post(f"/claims/{cid}/submit")
        with self.app.app_context():
            self.assertEqual(db.session.get(Claim, cid).status, "submitted")

    def test_more_info_resubmit_requires_missing_document(self):
        with self.app.app_context():
            claim = Claim(id=1005, policy_id=101, member_id=201, hospital_id=1, claim_type="reimbursement",
                          treatment_type="inpatient", admission_date=self.today - datetime.timedelta(days=9),
                          discharge_date=self.today - datetime.timedelta(days=7),
                          requested_amount_inr=Decimal("9000"), status="more_info")
            db.session.add(claim)
            db.session.add_all([
                ClaimDocument(claim_id=1005, document_type="hospital_bill", checklist_status="received"),
                ClaimDocument(claim_id=1005, document_type="discharge_summary", checklist_status="missing"),
            ])
            db.session.commit()
        self.login("owner")
        resp = self.client.post("/claims/1005/respond", data={"response_note": "see attached"},
                                content_type="multipart/form-data", follow_redirects=True)
        self.assertIn(b"Discharge summary is required", resp.data)
        with self.app.app_context():
            self.assertEqual(db.session.get(Claim, 1005).status, "more_info")
        self.client.post("/claims/1005/respond",
                         data={"response_note": "see attached", "file_discharge_summary": pdf("d.pdf")},
                         content_type="multipart/form-data")
        with self.app.app_context():
            self.assertEqual(db.session.get(Claim, 1005).status, "submitted")

    def test_claim_pages_render(self):
        self.login("owner")
        self.assertEqual(self.client.get("/claims/new").status_code, 200)
        self.client.post("/claims/new", data=self.claim_form("draft"), content_type="multipart/form-data")
        with self.app.app_context():
            cid = self.latest_claim().id
        resp = self.client.get(f"/claims/{cid}")
        self.assertEqual(resp.status_code, 200)
        self.assertIn(b"file_hospital_bill", resp.data)
        self.assertIn(b"Discharge report", resp.data)

    def test_hospital_desk_can_start_claim_from_policy_id_only(self):
        """New patient: desk knows only the policy ID; no earlier claims exist for it."""
        with self.app.app_context():
            db.session.add(User(id=9, username="desk", password_hash=generate_password_hash("pw"),
                                display_name="Desk", role="hospital", hospital_id=1))
            db.session.commit()
            self.assertEqual(Claim.query.filter_by(policy_id=101).count(), 0)
        self.login("desk")
        page = self.client.get("/claims/new").data.decode()
        self.assertIn('id="policy_lookup"', page)
        self.assertNotIn("Policy #101", page)          # no list of everybody's policies
        info = self.client.get("/api/policies/101/members").get_json()
        self.assertTrue(info["is_active_today"])
        self.assertEqual(self.client.get("/api/policies/999/members").status_code, 404)
        data = self.claim_form("submit", file_hospital_bill=pdf("b.pdf"), file_discharge_summary=pdf("d.pdf"))
        data.pop("hospital_id")
        self.client.post("/claims/new", data=data, content_type="multipart/form-data")
        with self.app.app_context():
            claim = self.latest_claim()
            self.assertEqual((claim.policy_id, claim.claim_type, claim.hospital_id, claim.status),
                             (101, "cashless", 1, "submitted"))

    def test_returning_patient_sees_only_own_hospital_visits(self):
        with self.app.app_context():
            db.session.add_all([
                Hospital(id=2, name="H2", city="C", network_status=True),
                User(id=9, username="desk", password_hash=generate_password_hash("pw"),
                     display_name="Desk", role="hospital", hospital_id=1)])
            db.session.flush()
            base = dict(policy_id=101, member_id=201, claim_type="cashless", treatment_type="inpatient",
                        admission_date=self.today - datetime.timedelta(days=30),
                        discharge_date=self.today - datetime.timedelta(days=27),
                        requested_amount_inr=Decimal("5000"), status="paid")
            db.session.add_all([Claim(id=11, hospital_id=1, **base), Claim(id=12, hospital_id=2, **base)])
            db.session.commit()
        self.login("desk")
        visits = self.client.get("/api/policies/101/members").get_json()["previous_visits"]
        self.assertEqual([v["claim_id"] for v in visits], [11])      # not the other hospital's #12
        self.client.get("/logout")
        self.login("owner")                                           # policyholders get no visit list
        self.assertEqual(self.client.get("/api/policies/101/members").get_json()["previous_visits"], [])


if __name__ == "__main__":
    unittest.main()
