# Health Insurance Claims Processing Simulator

An individual full-stack educational simulator built exclusively with **Python, Flask, SQLAlchemy 2.0, Jinja2, Bootstrap 5, and MySQL Server 8.0** based on the Business Requirements Document (BRD v1.0).

---

## 1. Quick Start with MySQL Server

### Step 1: Ensure MySQL Service is Running
Start your local MySQL service (e.g. from an Administrator Command Prompt or `services.msc`):
```cmd
net start MYSQL80
```

### Step 2: Seed the MySQL Database
Run the database seed script to auto-create the `health_claims_simulator` database and import all 9 CSV files with hashed passwords:
```powershell
pip install -r requirements.txt
python seed_data.py
```

### Step 3: Start the Flask Application
```powershell
python run.py
```
Open your browser and navigate to: **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

---

## 2. MySQL Configuration
Copy `.env.example` to `.env` and set your own values (they override the defaults in `config.py`):
* **Host / Port:** `127.0.0.1:3306`
* **User / Password:** your MySQL credentials (`DB_USER`, `DB_PASSWORD`)
* **Database Name:** `health_claims_simulator`
* **Driver:** `PyMySQL` (`mysql+pymysql`)

---

## 3. User Accounts
Accounts (policyholders, hospital desks, claims officers, administrator) are loaded from `database/data/users.csv` when you run `seed_data.py`. The initial password is set by `DEFAULT_PASSWORD` in `seed_data.py`; change it before sharing the app.

---

## 4. Project Structure
```text
Health_Insurance_Claims_Simulator_BRD/
├── README.md
├── requirements.txt
├── .env.example            # database settings template
├── config.py               # app + MySQL configuration
├── run.py                  # start the web app
├── seed_data.py            # create tables and load database/data/*.csv
├── app/
│   ├── __init__.py         # app factory
│   ├── extensions.py
│   ├── models.py           # SQLAlchemy models
│   ├── auth/               # login, logout, role decorators
│   ├── claims/             # dashboard, claim list, new claim, claim detail
│   ├── officer/            # review queue and approval decisions
│   ├── admin/              # settlements, reference data, reports
│   ├── services/           # payout calculator and business rules
│   ├── templates/          # Jinja pages (auth, claims, officer, admin, shared)
│   └── static/             # css, js, img
├── database/
│   ├── schema.sql          # optional: raw MySQL schema
│   ├── complete_practice_dataset.sql  # optional: raw SQL seed
│   └── data/               # CSV seed files (+ dataset notes)
├── docs/
│   └── Health_Insurance_Claims_Simulator_BRD.docx
└── tests/
    ├── test_app.py
    └── test_document_uploads.py
```

---

## 5. Key Pre-Seeded Scenarios (BRD Section 16)

* **Claim #1001 (Paid):** Cashless claim at CityCare Hospital, ₹28,000 requested, ₹26,000 eligible, Paid ₹21,600 to Hospital.
* **Claim #1002 (Rejected):** Daycare procedure filed under Essential Care plan (covers only Inpatient) $\rightarrow$ Demonstrates treatment coverage rule.
* **Claim #1003 (Approved):** Cashless claim at Lotus Medical Centre for ₹16,000 eligible amount $\rightarrow$ Ready for Admin to click "Record Settlement".
* **Claim #1004 (In Review):** Currently in review by Officer Meera.
* **Claim #1005 (More Info):** Reimbursement claim with missing discharge summary $\rightarrow$ Submitter uploads the discharge summary and resubmits.
* **Claim #1006 (Rejected):** Admission date fell outside policy coverage dates $\rightarrow$ Demonstrates active policy date rule.
* **Claim #1007 (Submitted):** Unassigned claim in the Claims Officer work queue.
* **Claim #1011 & #1012 (Duplicate Warning):** Same member, hospital, and admission dates $\rightarrow$ Triggers visible amber review warning.
* **Claim #1013 (Future Admission Draft):** Draft with future admission date $\rightarrow$ Submission is blocked until date is valid.

---

## 6. Automated Test Suite
Run the test suite against MySQL to verify all business rules, role security boundaries, race condition prevention, and financial formulas:
```powershell
python -m unittest discover -s tests -t .
```
Outputs:
```text
Ran 8 tests in 1.408s - OK
```

## 7. Document Uploads (Hospital Bill & Discharge Summary)
Every claim must have a **hospital bill** and a **discharge summary** uploaded before it can be submitted.

* PDF, JPG or PNG, up to 10 MB. Files are saved under `uploads/claim_<id>/` (git-ignored; change with the `UPLOAD_FOLDER` env var).
* New claim form: both files are required for **Submit**; a **Save draft** can be made without them and the files added later from the claim page.
* A claim returned for more information can only be resubmitted once both documents are on file.
* Claim detail shows each uploaded file with View / Download links. Access follows claim visibility (owner, matching hospital desk, officers, admin).
* Seeded demo claims keep their original "received / missing" checklist data without files.
* **Existing database?** Run `database/migration_add_document_uploads.sql` once to add the new columns (fresh installs via `schema.sql` already have them).
* Upload tests run without MySQL: `python -m unittest tests.test_document_uploads`


## Change History via MySQL Triggers

Every INSERT / UPDATE / DELETE on `claims`, `claim_documents` and `settlements` is recorded
automatically by MySQL triggers into the `claim_audit_log` table (old values, new values,
list of changed columns, DB user, timestamp). It complements `claim_history` (the workflow
timeline written by the app) and also captures changes made directly in SQL.

- Definition: `database/triggers.sql` (table + 9 triggers, safe to re-run)
- Fresh install: `python seed_data.py` installs them automatically (after seeding)
- Existing database: `python install_triggers.py`  (or `mysql -u root -p < database/triggers.sql`)

Example: full history of one claim
```sql
SELECT changed_at, table_name, action, changed_fields,
       old_values->>'$.status' AS old_status, new_values->>'$.status' AS new_status
FROM claim_audit_log WHERE claim_id = 1001 ORDER BY id;
```
