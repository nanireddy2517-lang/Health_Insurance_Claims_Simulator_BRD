import datetime
from decimal import Decimal
from flask import (
    Blueprint,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from app.auth.decorators import get_current_user, role_required
from app.extensions import db
from app.models import Claim, ClaimDocument, ClaimHistory, User
from app.services.calculator import (
    calculate_payout,
    get_calculation_breakdown,
    get_remaining_cover,
)
from app.services.rules import check_potential_duplicates, record_history_event

officer_bp = Blueprint("officer", __name__, url_prefix="/officer")


@officer_bp.route("/queue")
@role_required("claims_officer", "admin")
def review_queue():
    user = get_current_user()
    filter_mode = request.args.get("view", "all")  # 'all', 'mine', 'unassigned'

    query = Claim.query.filter(Claim.status.in_(["submitted", "in_review", "more_info"]))

    if filter_mode == "mine":
        query = query.filter(Claim.officer_user_id == user.id)
    elif filter_mode == "unassigned":
        query = query.filter(Claim.status == "submitted", Claim.officer_user_id == None)

    claims = query.order_by(Claim.created_at.asc()).all()

    return render_template(
        "officer/queue.html",
        claims=claims,
        user=user,
        filter_mode=filter_mode,
    )


@officer_bp.route("/claim/<int:claim_id>/assign", methods=["POST"])
@role_required("claims_officer", "admin")
def assign_claim(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    # Concurrency and race condition protection (FR05)
    if claim.status != "submitted":
        flash(f"Claim #{claim.id} is already in state '{claim.status}' and cannot be claimed from queue.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    if claim.officer_user_id and claim.officer_user_id != user.id:
        assigned_officer = User.query.get(claim.officer_user_id)
        flash(
            f"Claim #{claim.id} has already been assigned to officer {assigned_officer.display_name if assigned_officer else 'another officer'}.",
            "danger",
        )
        return redirect(url_for("officer.review_queue"))

    claim.officer_user_id = user.id
    claim.status = "in_review"

    record_history_event(
        claim=claim,
        from_status="submitted",
        to_status="in_review",
        actor_user_id=user.id,
        note=f"Claim assigned to officer {user.display_name} for review.",
    )
    db.session.commit()
    flash(f"Claim #{claim.id} assigned to you and moved to IN REVIEW.", "success")
    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


@officer_bp.route("/claim/<int:claim_id>/request-info", methods=["POST"])
@role_required("claims_officer", "admin")
def request_info(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    if claim.status != "in_review":
        flash("Can only request information for claims currently in review.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    reason = request.form.get("reason", "").strip()
    missing_item = request.form.get("missing_item", "").strip()

    if not reason:
        flash("A clear reason is required when requesting more information.", "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    full_note = f"Information Requested: {reason}"
    if missing_item:
        full_note += f" | Checklist Item Needed: {missing_item}"

    claim.status = "more_info"
    record_history_event(
        claim=claim,
        from_status="in_review",
        to_status="more_info",
        actor_user_id=user.id,
        note=full_note,
    )
    db.session.commit()
    flash(f"Claim #{claim.id} moved to MORE_INFO. Submitter has been requested for details.", "info")
    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


@officer_bp.route("/claim/<int:claim_id>/decide", methods=["POST"])
@role_required("claims_officer", "admin")
def decide_claim(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    if claim.status != "in_review":
        flash("Only claims currently in review can be decided.", "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    decision = request.form.get("decision", "").strip()  # 'approve' or 'reject'
    reason = request.form.get("reason", "").strip()

    if not reason:
        flash("A written reason is strictly required for claim decisions.", "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    if decision == "approve":
        eligible_str = request.form.get("eligible_amount", "").strip()
        try:
            eligible_amount = Decimal(eligible_str)
        except (ValueError, TypeError):
            flash("Invalid eligible amount entered.", "danger")
            return redirect(url_for("claims.claim_detail", claim_id=claim.id))

        if eligible_amount <= Decimal("0.00"):
            flash("Eligible amount must be greater than ₹0 for approval.", "danger")
            return redirect(url_for("claims.claim_detail", claim_id=claim.id))

        if eligible_amount > claim.requested_amount_inr:
            flash(
                f"Eligible amount (₹{eligible_amount}) cannot exceed the requested amount (₹{claim.requested_amount_inr}).",
                "danger",
            )
            return redirect(url_for("claims.claim_detail", claim_id=claim.id))

        remaining_cover = get_remaining_cover(claim.policy, exclude_claim_id=claim.id)
        if eligible_amount > remaining_cover:
            flash(
                f"Eligible amount (₹{eligible_amount}) exceeds the available policy cover (₹{remaining_cover}).",
                "danger",
            )
            return redirect(url_for("claims.claim_detail", claim_id=claim.id))

        # Check plan treatment type
        if not claim.policy.plan.covers_treatment(claim.treatment_type):
            flash(
                f"Cannot approve: Treatment type '{claim.treatment_type}' is outside '{claim.policy.plan.name}' coverage.",
                "danger",
            )
            return redirect(url_for("claims.claim_detail", claim_id=claim.id))

        payout = calculate_payout(
            eligible_amount=eligible_amount,
            deductible=claim.policy.plan.deductible_inr,
            copay_percent=claim.policy.plan.copay_percent,
        )

        claim.status = "approved"
        claim.eligible_amount_inr = eligible_amount
        note = f"Approved for eligible ₹{eligible_amount} (Calculated simulated payout: ₹{payout}). Reason: {reason}"

        record_history_event(
            claim=claim,
            from_status="in_review",
            to_status="approved",
            actor_user_id=user.id,
            note=note,
        )
        db.session.commit()
        flash(f"Claim #{claim.id} approved successfully for ₹{eligible_amount}.", "success")

    elif decision == "reject":
        claim.status = "rejected"
        claim.eligible_amount_inr = Decimal("0.00")
        note = f"Claim Rejected. Reason: {reason}"

        record_history_event(
            claim=claim,
            from_status="in_review",
            to_status="rejected",
            actor_user_id=user.id,
            note=note,
        )
        db.session.commit()
        flash(f"Claim #{claim.id} rejected.", "warning")
    else:
        flash("Invalid decision action.", "danger")

    return redirect(url_for("claims.claim_detail", claim_id=claim.id))
