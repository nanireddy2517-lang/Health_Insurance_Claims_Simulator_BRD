// Health Insurance Claims Simulator - Client JS

document.addEventListener("DOMContentLoaded", function () {
    // 1. Dynamic Member and Plan loading on Policy Selection
    const policySelect = document.getElementById("policy_id");
    const memberSelect = document.getElementById("member_id");
    const planDetailsBadge = document.getElementById("plan_details_badge");

    window.form_refresh = window.form_refresh || function () {};
    function resetPolicy(msg) {
        memberSelect.innerHTML = '<option value="">-- First Select a Policy --</option>';
        if (planDetailsBadge) planDetailsBadge.textContent = "";
        if (policySelect.tagName !== "SELECT") { policySelect.value = ""; policySelect.dataset.plan = ""; }
        const out = document.getElementById("policy_lookup_msg");
        if (out) out.innerHTML = msg || "";
    }

    // Loads the covered members + plan for a policy; returns a promise
    function loadPolicy(policyId) {
        return fetch(`/api/policies/${policyId}/members`)
            .then(response => {
                if (!response.ok) throw new Error("not-found");
                return response.json();
            })
            .then(data => {
                memberSelect.innerHTML = '<option value="">-- Choose Covered Member --</option>';
                data.members.forEach(member => {
                    const opt = document.createElement("option");
                    opt.value = member.id;
                    opt.textContent = `${member.display_name} (${member.relationship})`;
                    memberSelect.appendChild(opt);
                });
                if (planDetailsBadge) {
                    planDetailsBadge.innerHTML = `<span class="pill pill-info">${data.plan_name}</span> <span class="pill pill-muted">Covers: ${data.covered_treatment_types}</span>`;
                }
                return data;
            });
    }

    if (policySelect && memberSelect) {
        if (policySelect.tagName === "SELECT") {
            // Policyholder: choose from own policies
            policySelect.addEventListener("change", function () {
                if (!this.value) return resetPolicy();
                loadPolicy(this.value).catch(err => console.error("Error fetching members:", err));
            });
        } else {
            // Hospital desk: type the policy ID the patient brought and verify it
            const lookupInput = document.getElementById("policy_lookup");
            const lookupBtn = document.getElementById("policy_lookup_btn");
            const msg = document.getElementById("policy_lookup_msg");
            const verify = function () {
                const id = (lookupInput.value || "").trim().replace(/^pol-?/i, "");
                if (!/^\d+$/.test(id)) return resetPolicy('<span class="text-danger">Enter a numeric policy ID.</span>');
                resetPolicy("Checking...");
                loadPolicy(id).then(data => {
                    policySelect.value = data.policy_id;
                    policySelect.dataset.plan = data.plan_name;
                    msg.innerHTML = data.is_active_today
                        ? `<span class="text-success"><i class="bi bi-check-circle me-1"></i>Policy #${data.policy_id} is active (${data.start_date} to ${data.end_date}). Choose the patient below.</span>`
                        : `<span class="text-danger"><i class="bi bi-exclamation-triangle me-1"></i>Policy #${data.policy_id} is ${data.status} / outside its period (${data.start_date} to ${data.end_date}). A claim cannot be submitted against it.</span>`;
                    // Earlier visits of this policy at this hospital (returning patient)
                    const esc = t => String(t).replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
                    if (data.previous_visits && data.previous_visits.length) {
                        msg.innerHTML += '<div class="mt-2 p-2 border rounded bg-white"><div class="fw-semibold mb-1"><i class="bi bi-clock-history me-1"></i>Earlier visits at this hospital</div>' +
                            data.previous_visits.map(v => `<div><a href="${esc(v.url)}">#${esc(v.claim_id)}</a> &middot; ${esc(v.member)} &middot; ${esc(v.admission_date)} to ${esc(v.discharge_date)} &middot; <span class="text-capitalize">${esc(v.status.replace("_", " "))}</span></div>`).join("") +
                            '<div class="text-muted mt-1">Returning patient: pick the member below and enter the new stay. The same member, dates and type as an existing claim is flagged as a possible duplicate.</div></div>';
                    } else {
                        msg.innerHTML += '<div class="text-muted mt-1">First visit to this hospital for this policy.</div>';
                    }
                    form_refresh();
                }).catch(() => resetPolicy(`<span class="text-danger"><i class="bi bi-x-circle me-1"></i>No policy found with ID ${id}.</span>`));
            };
            lookupBtn.addEventListener("click", verify);
            lookupInput.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); verify(); } });
            lookupInput.addEventListener("input", () => { if (policySelect.value) resetPolicy(); });
        }
    }

    // 3. Officer Decision Live Math Preview
    const eligibleInput = document.getElementById("officer_eligible_amount");
    const livePayoutPreview = document.getElementById("live_payout_preview");

    if (eligibleInput && livePayoutPreview) {
        const deductible = parseFloat(eligibleInput.getAttribute("data-deductible") || "0");
        const copayPercent = parseFloat(eligibleInput.getAttribute("data-copay") || "0");

        function updatePayoutPreview() {
            const eligible = parseFloat(eligibleInput.value) || 0;
            if (eligible <= 0) {
                livePayoutPreview.textContent = "₹0.00";
                return;
            }
            const minDed = Math.min(eligible, deductible);
            const base = eligible - minDed;
            const factor = 1.0 - (copayPercent / 100.0);
            const payout = (base * factor).toFixed(2);
            livePayoutPreview.textContent = `₹${Number(payout).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
        }

        eligibleInput.addEventListener("input", updatePayoutPreview);
        updatePayoutPreview();
    }

    // 4. New-claim live summary + completeness meter
    const form = document.getElementById("claimForm");
    if (form && document.getElementById("sum_amount")) {
        const $ = id => document.getElementById(id);
        const hospital = $("hospital_id");
        const val = n => (form.elements[n] || {}).value || "";
        const selText = el => (el && el.selectedIndex > 0 ? el.options[el.selectedIndex].text : "");
        function refresh() {
            const amt = parseFloat(val("requested_amount")) || 0;
            $("sum_amount").textContent = "₹" + amt.toLocaleString("en-IN");
            $("sum_member").textContent = selText(memberSelect).replace(/ \(.*\)$/, "") || "–";
            $("sum_plan").textContent = (policySelect.tagName === "SELECT" ? (selText(policySelect).split("·")[1] || "").replace(/\(.*$/, "").trim() : (policySelect.dataset.plan || "")) || "–";
            let hName = "";
            if (hospital) hName = hospital.tagName === "SELECT" ? (hospital.selectedIndex > 0 ? hospital.options[hospital.selectedIndex].dataset.label : "") : hospital.dataset.label;
            $("sum_hospital").textContent = hName || "–";
            const a = val("admission_date"), d = val("discharge_date");
            if (a && d) {
                const days = Math.round((new Date(d) - new Date(a)) / 86400000);
                $("sum_stay").textContent = days >= 0 ? (days === 0 ? "Same day" : days + (days === 1 ? " night" : " nights")) : "Check dates";
            } else { $("sum_stay").textContent = "–"; }
            const got = ["file_hospital_bill", "file_discharge_summary"].filter(n => form.elements[n] && form.elements[n].files && form.elements[n].files.length).length;
            $("sum_docs").textContent = got + " of 2 uploaded";
            const checks = [val("policy_id"), val("member_id"), hospital ? (hospital.tagName === "SELECT" ? hospital.value : "x") : "x", a, d, amt > 0 ? "x" : ""];
            const pct = Math.round(checks.filter(Boolean).length / checks.length * 100);
            $("sum_bar").style.width = pct + "%";
            $("sum_pct").textContent = pct + "% complete";
        }
        window.form_refresh = refresh;
        form.addEventListener("input", refresh);
        form.addEventListener("change", refresh);
        refresh();
    }
});
