import datetime
from decimal import Decimal
from typing import List, Optional, Tuple

from app.extensions import db
from app.models import Claim, ClaimDocument, ClaimHistory, Hospital, Member, Policy, User
from app.services.calculator import get_remaining_cover


VALID_TRANSITIONS = {
    "draft": ["submitted"],
    "submitted": ["in_review"],
    "in_review": ["more_info", "approved", "rejected"],
    "more_info": ["submitted"],
    "approved": ["paid"],
    "rejected": [],
    "paid": [],
}


def can_transition(from_status: str, to_status: str) -> bool:
    """Check if the transition is structurally permitted by the state machine."""
    allowed = VALID_TRANSITIONS.get(from_status, [])
    return to_status in allowed


def record_history_event(
    claim: Claim,
    from_status: Optional[str],
    to_status: str,
    actor_user_id: Optional[int],
    note: str,
    event_date: Optional[datetime.date] = None
) -> ClaimHistory:
    """
    Append an immutable event to claim_history with sequence auto-increment.
    """
    # Count existing events for this claim to determine next sequence_no
    seq = (
        db.session.query(db.func.coalesce(db.func.max(ClaimHistory.sequence_no), 0))
        .filter(ClaimHistory.claim_id == claim.id)
        .scalar()
    ) + 1

    today = event_date or datetime.date.today()
    history = ClaimHistory(
        claim_id=claim.id,
        sequence_no=seq,
        from_status=from_status,
        to_status=to_status,
        actor_user_id=actor_user_id,
        note=note,
        timestamp=datetime.datetime.utcnow(),
        event_date=today,
    )
    db.session.add(history)
    return history


def check_potential_duplicates(
    member_id: int,
    hospital_id: int,
    admission_date: datetime.date,
    discharge_date: datetime.date,
    claim_type: str,
    exclude_claim_id: Optional[int] = None
) -> List[Claim]:
    """
    Duplicate Rule:
    Identical member, hospital, admission date, discharge date, and claim type
    raises a visible review warning (does not auto-reject).
    """
    query = Claim.query.filter(
        Claim.member_id == member_id,
        Claim.hospital_id == hospital_id,
        Claim.admission_date == admission_date,
        Claim.discharge_date == discharge_date,
        Claim.claim_type == claim_type,
    )
    if exclude_claim_id:
        query = query.filter(Claim.id != exclude_claim_id)

    return query.all()


def validate_claim_data(
    policy: Policy,
    member: Member,
    hospital: Hospital,
    user: User,
    claim_type: str,
    treatment_type: str,
    admission_date: datetime.date,
    discharge_date: datetime.date,
    requested_amount: Decimal,
    is_submission: bool = False
) -> Tuple[bool, List[str]]:
    """
    Full business rule validation for claim creation and submission:
    - Member must belong to policy
    - Dates consistency
    - Future admission disallowed on submission (allowed on draft)
    - Active policy coverage dates
    - Plan covers treatment type
    - Hospital network check for cashless
    - User role scoping (hospital user hospital_id must match, policyholder must own policy)
    """
    errors: List[str] = []
    today = datetime.date.today()

    # 1. Member-Policy Relationship
    if member.policy_id != policy.id:
        errors.append(f"Member '{member.display_name}' does not belong to Policy #{policy.id}.")

    # 2. Amount Check
    if requested_amount <= Decimal("0.00"):
        errors.append("Requested amount must be greater than ₹0.")

    # 3. Date Sequence Check
    if discharge_date < admission_date:
        errors.append("Discharge date cannot be earlier than admission date.")

    # 4. Future Admission Rule
    if is_submission and admission_date > today:
        errors.append(
            f"Admission date ({admission_date}) is in the future. Cannot submit claim until admission has occurred."
        )

    # 5. Policy Active Rule
    if not policy.is_active_on(admission_date):
        errors.append(
            f"Policy #{policy.id} was not active on admission date ({admission_date}). "
            f"Valid policy period: {policy.start_date} to {policy.end_date} (Status: {policy.status})."
        )

    # 6. Plan Treatment Type Coverage
    if not policy.plan.covers_treatment(treatment_type):
        errors.append(
            f"Treatment type '{treatment_type}' is not covered under plan '{policy.plan.name}'. "
            f"Covered types: {policy.plan.covered_treatment_types}."
        )

    # 7. Cashless Hospital & User Scope
    if claim_type == "cashless":
        if not hospital.network_status:
            errors.append(f"Hospital '{hospital.name}' is not an empanelled network hospital for cashless claims.")
        if user.role != "hospital" or user.hospital_id != hospital.id:
            errors.append(f"Cashless claims must be submitted by the authorized desk of '{hospital.name}'.")

    # 8. Reimbursement Scope
    if claim_type == "reimbursement":
        if user.role != "policyholder" or policy.holder_user_id != user.id:
            errors.append("Reimbursement claims can only be submitted by the policyholder.")

    return len(errors) == 0, errors
