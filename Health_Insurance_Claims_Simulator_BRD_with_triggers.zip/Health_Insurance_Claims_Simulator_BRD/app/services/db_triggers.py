"""
Installs the MySQL audit triggers defined in database/triggers.sql.

The .sql file is the single source of truth (usable from the mysql CLI /
Workbench). This helper parses it so Python can install the same triggers
(used by seed_data.py and install_triggers.py).
"""
import os
import re

from sqlalchemy import text

from app.extensions import db

TRIGGERS_SQL = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "database",
    "triggers.sql",
)


def _strip_comments(sql: str) -> str:
    return "\n".join(re.sub(r"--.*$", "", line) for line in sql.splitlines())


def load_statements(path: str = TRIGGERS_SQL) -> list:
    """Split triggers.sql into individual executable statements."""
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    head, _, tail = raw.partition("DELIMITER $$")
    tail = tail.rsplit("DELIMITER ;", 1)[0]

    statements = []
    for chunk in _strip_comments(head).split(";"):
        chunk = chunk.strip()
        # USE is skipped: the engine is already bound to the configured database
        if chunk and not chunk.upper().startswith("USE "):
            statements.append(chunk)
    for chunk in _strip_comments(tail).split("$$"):
        chunk = chunk.strip()
        if chunk:
            statements.append(chunk)
    return statements


def install_triggers() -> int:
    """Create/replace all audit triggers. Returns number of statements run."""
    statements = load_statements()
    with db.engine.begin() as conn:
        for stmt in statements:
            # exec_driver_sql avoids SQLAlchemy treating ':' / '%' as bind params
            conn.exec_driver_sql(stmt)
    return len(statements)
