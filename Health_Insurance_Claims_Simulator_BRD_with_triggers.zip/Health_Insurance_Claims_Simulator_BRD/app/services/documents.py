"""Helpers for the claim document checklist (hospital bill + discharge summary uploads)."""
import datetime
import os
import uuid
from typing import Dict, List, Optional, Tuple

from flask import current_app
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from app.models import ClaimDocument

# form field name -> document_type stored in claim_documents
REQUIRED_DOCUMENTS: Dict[str, str] = {
    "file_hospital_bill": "hospital_bill",
    "file_discharge_summary": "discharge_summary",
}

DOCUMENT_LABELS = {
    "hospital_bill": "Hospital bill",
    "discharge_summary": "Discharge summary",
}


def _extension(filename: str) -> str:
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def has_upload(file: Optional[FileStorage]) -> bool:
    return bool(file and file.filename)


def validate_upload(file: FileStorage, label: str) -> Optional[str]:
    """Return an error message if the file is not acceptable, else None."""
    allowed = current_app.config["ALLOWED_UPLOAD_EXTENSIONS"]
    if _extension(file.filename) not in allowed:
        return f"{label}: only {', '.join(sorted(e.upper() for e in allowed))} files are allowed."
    # Peek at the size without loading the whole file into memory
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(0)
    if size == 0:
        return f"{label}: the selected file is empty."
    return None


def validate_uploads_from_request(files, require_all: bool, existing: Optional[List[ClaimDocument]] = None) -> List[str]:
    """
    Validate the two checklist uploads in a request.

    require_all=True means each required document must either be uploaded now
    or already be on file (existing ClaimDocument rows).
    """
    errors: List[str] = []
    on_file = {d.document_type for d in (existing or []) if d.is_satisfied}
    for field, doc_type in REQUIRED_DOCUMENTS.items():
        label = DOCUMENT_LABELS[doc_type]
        f = files.get(field)
        if has_upload(f):
            err = validate_upload(f, label)
            if err:
                errors.append(err)
        elif require_all and doc_type not in on_file:
            errors.append(f"{label} is required. Please upload it before submitting.")
    return errors


def save_upload(file: FileStorage, claim_id: int, doc_type: str) -> Tuple[str, str]:
    """Store the file on disk and return (original_filename, stored_filename)."""
    folder = os.path.join(current_app.config["UPLOAD_FOLDER"], f"claim_{claim_id}")
    os.makedirs(folder, exist_ok=True)
    original = secure_filename(file.filename) or f"{doc_type}.{_extension(file.filename)}"
    stored = f"{doc_type}_{uuid.uuid4().hex[:12]}.{_extension(original)}"
    file.save(os.path.join(folder, stored))
    return original, stored


def apply_uploads(claim, files) -> int:
    """
    Save any uploaded checklist files for this claim, creating/updating its
    ClaimDocument rows. Returns the number of files stored.
    """
    from app.extensions import db  # local import avoids circulars at module load

    by_type = {d.document_type: d for d in claim.documents}
    saved = 0
    for field, doc_type in REQUIRED_DOCUMENTS.items():
        f = files.get(field)
        doc = by_type.get(doc_type)
        if doc is None:
            doc = ClaimDocument(claim_id=claim.id, document_type=doc_type, checklist_status="missing")
            db.session.add(doc)
            by_type[doc_type] = doc
        if has_upload(f):
            original, stored = save_upload(f, claim.id, doc_type)
            doc.original_filename = original
            doc.stored_filename = stored
            doc.uploaded_at = datetime.datetime.now()
            doc.checklist_status = "received"
            saved += 1
    return saved


def missing_documents(claim) -> List[str]:
    """Labels of required documents that are not on file for this claim."""
    by_type = {d.document_type: d for d in claim.documents}
    return [
        DOCUMENT_LABELS[t]
        for t in REQUIRED_DOCUMENTS.values()
        if t not in by_type or not by_type[t].is_satisfied
    ]
