from decimal import Decimal, ROUND_HALF_UP
from typing import Optional
from sqlalchemy import func

from app.extensions import db
from app.models import Claim, Policy, Settlement


def get_prior_paid_payouts(policy_id: int, exclude_claim_id: Optional[int] = None) -> Decimal:
    """
    Calculate the sum of prior simulated paid payouts for a policy.
    Uses settlement amounts for claims in 'paid' status.
    """
    query = (
        db.session.query(func.coalesce(func.sum(Settlement.amount_inr), Decimal("0.00")))
        .join(Claim, Settlement.claim_id == Claim.id)
        .filter(Claim.policy_id == policy_id, Claim.status == "paid")
    )
    if exclude_claim_id:
        query = query.filter(Claim.id != exclude_claim_id)

    total = query.scalar()
    return Decimal(str(total or "0.00"))


def get_remaining_cover(policy: Policy, exclude_claim_id: Optional[int] = None) -> Decimal:
    """
    Remaining cover = Plan annual limit - prior simulated paid payouts for this policy.
    Guaranteed not to return less than 0.
    """
    annual_limit = Decimal(str(policy.plan.annual_limit_inr))
    prior_paid = get_prior_paid_payouts(policy.id, exclude_claim_id=exclude_claim_id)
    remaining = annual_limit - prior_paid
    return max(Decimal("0.00"), remaining)


def calculate_payout(
    eligible_amount: Decimal,
    deductible: Decimal,
    copay_percent: Decimal
) -> Decimal:
    """
    Calculate simulated payout according to the BRD specification:
    Base = eligible - min(eligible, deductible)
    Payout = round(Base * (1 - copay_percent / 100), 2)
    Uses Python Decimal with standard ROUND_HALF_UP rounding.
    """
    eligible = Decimal(str(eligible_amount))
    ded = Decimal(str(deductible))
    copay = Decimal(str(copay_percent))

    # Base amount after deductible
    min_deductible = min(eligible, ded)
    base_amount = eligible - min_deductible

    # Insurer share factor (1 - copay/100)
    factor = Decimal("1.00") - (copay / Decimal("100.00"))
    raw_payout = base_amount * factor

    # Round half up to 2 decimal places
    payout = raw_payout.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return payout


def get_calculation_breakdown(
    requested_amount: Decimal,
    eligible_amount: Decimal,
    deductible: Decimal,
    copay_percent: Decimal
) -> dict:
    """
    Returns a complete, transparent breakdown for the decision view:
    - requested_amount
    - eligible_amount
    - disallowed_amount (requested - eligible)
    - deductible_applied
    - copay_share (patient's co-pay out-of-pocket)
    - simulated_payout (insurer simulated payout)
    """
    req = Decimal(str(requested_amount))
    elig = Decimal(str(eligible_amount))
    ded = Decimal(str(deductible))
    copay = Decimal(str(copay_percent))

    disallowed = max(Decimal("0.00"), req - elig)
    deductible_applied = min(elig, ded)
    base_after_deductible = elig - deductible_applied
    copay_factor = copay / Decimal("100.00")
    copay_share = (base_after_deductible * copay_factor).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    simulated_payout = (base_after_deductible - copay_share).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    return {
        "requested_amount": req,
        "eligible_amount": elig,
        "disallowed_amount": disallowed,
        "deductible_applied": deductible_applied,
        "copay_percent": copay,
        "copay_share": copay_share,
        "simulated_payout": simulated_payout,
    }
