import os
from decimal import Decimal
from typing import Optional

from flask import Flask, render_template, session

from app.auth.decorators import generate_csrf_token, validate_csrf_token
from config import Config
from app.extensions import db


class CurrentUserProxy:
    """Proxy providing convenient current_user access in templates."""
    @property
    def is_authenticated(self) -> bool:
        return "user_id" in session

    @property
    def id(self) -> Optional[int]:
        return session.get("user_id")

    @property
    def username(self) -> Optional[str]:
        return session.get("username")

    @property
    def display_name(self) -> Optional[str]:
        return session.get("display_name")

    @property
    def role(self) -> Optional[str]:
        return session.get("user_role")

    @property
    def hospital_id(self) -> Optional[int]:
        return session.get("hospital_id")


def format_inr(value) -> str:
    """Format numeric/decimal value as Indian Rupee string."""
    if value is None:
        return "₹0.00"
    try:
        val = Decimal(str(value))
        return f"₹{val:,.2f}"
    except Exception:
        return f"₹{value}"


def create_app(config_class=Config) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)

    # Register blueprints
    from app.auth.routes import auth_bp
    from app.claims.routes import claims_bp
    from app.officer.routes import officer_bp
    from app.admin.routes import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(claims_bp)
    app.register_blueprint(officer_bp)
    app.register_blueprint(admin_bp)

    # CSRF protection hook
    @app.before_request
    def check_csrf():
        # Validate CSRF on all state-altering POST requests
        validate_csrf_token()

    # Template context processors and filters
    @app.context_processor
    def inject_context():
        return {
            "current_user": CurrentUserProxy(),
            "csrf_token": generate_csrf_token(),
            "format_inr": format_inr,
            "db_engine_name": "MySQL 8.0 (health_claims_simulator)",
        }

    app.jinja_env.filters["format_inr"] = format_inr

    # Friendly error handlers
    @app.errorhandler(403)
    def forbidden_error(e):
        return render_template("shared/403.html"), 403

    @app.errorhandler(404)
    def not_found_error(e):
        return render_template("shared/404.html"), 404

    @app.errorhandler(500)
    def internal_error(e):
        db.session.rollback()
        return render_template("shared/500.html"), 500

    return app
