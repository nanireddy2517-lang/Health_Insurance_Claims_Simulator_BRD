import datetime
import os
from decimal import Decimal
from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from sqlalchemy import or_

from app.auth.decorators import get_current_user, login_required
from app.extensions import db
from app.models import (
    Claim,
    ClaimDocument,
    ClaimHistory,
    Hospital,
    Member,
    Plan,
    Policy,
    Settlement,
    User,
)
from app.services.calculator import (
    calculate_payout,
    get_calculation_breakdown,
    get_prior_paid_payouts,
    get_remaining_cover,
)
from app.services.documents import (
    apply_uploads,
    missing_documents,
    validate_uploads_from_request,
)
from app.services.rules import (
    check_potential_duplicates,
    record_history_event,
    validate_claim_data,
)

claims_bp = Blueprint("claims", __name__)


@claims_bp.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("claims.dashboard"))
    return redirect(url_for("auth.login"))


@claims_bp.route("/dashboard")
@login_required
def dashboard():
    user = get_current_user()
    if not user:
        return redirect(url_for("auth.login"))

    role = user.role
    context = {"user": user, "role": role}

    if role == "policyholder":
        policies = Policy.query.filter_by(holder_user_id=user.id).all()
        policy_ids = [p.id for p in policies]
        claims = (
            Claim.query.filter(Claim.policy_id.in_(policy_ids))
            .order_by(Claim.created_at.desc())
            .all()
            if policy_ids
            else []
        )
        context.update(
            {
                "policies": policies,
                "claims": claims,
                "draft_count": sum(1 for c in claims if c.status == "draft"),
                "in_review_count": sum(1 for c in claims if c.status in ("submitted", "in_review", "more_info")),
                "approved_count": sum(1 for c in claims if c.status == "approved"),
                "paid_count": sum(1 for c in claims if c.status == "paid"),
            }
        )

    elif role == "hospital":
        hospital = Hospital.query.get(user.hospital_id) if user.hospital_id else None
        claims = (
            Claim.query.filter_by(hospital_id=user.hospital_id)
            .order_by(Claim.created_at.desc())
            .all()
            if user.hospital_id
            else []
        )
        context.update(
            {
                "hospital": hospital,
                "claims": claims,
                "draft_count": sum(1 for c in claims if c.status == "draft"),
                "submitted_count": sum(1 for c in claims if c.status == "submitted"),
                "more_info_count": sum(1 for c in claims if c.status == "more_info"),
                "approved_count": sum(1 for c in claims if c.status == "approved"),
                "paid_count": sum(1 for c in claims if c.status == "paid"),
            }
        )

    elif role == "claims_officer":
        unassigned_count = Claim.query.filter_by(status="submitted", officer_user_id=None).count()
        my_review_count = Claim.query.filter_by(status="in_review", officer_user_id=user.id).count()
        more_info_count = Claim.query.filter_by(status="more_info", officer_user_id=user.id).count()
        my_total_decided = Claim.query.filter(
            Claim.officer_user_id == user.id, Claim.status.in_(["approved", "rejected", "paid"])
        ).count()
        recent_queue = (
            Claim.query.filter(Claim.status.in_(["submitted", "in_review", "more_info"]))
            .order_by(Claim.created_at.desc())
            .limit(10)
            .all()
        )
        context.update(
            {
                "unassigned_count": unassigned_count,
                "my_review_count": my_review_count,
                "more_info_count": more_info_count,
                "my_total_decided": my_total_decided,
                "recent_queue": recent_queue,
            }
        )

    elif role == "admin":
        pending_settlements = Claim.query.filter_by(status="approved").count()
        total_claims = Claim.query.count()
        total_settled_amount = db.session.query(
            db.func.coalesce(db.func.sum(Settlement.amount_inr), Decimal("0.00"))
        ).scalar()
        hospitals_count = Hospital.query.count()
        context.update(
            {
                "pending_settlements": pending_settlements,
                "total_claims": total_claims,
                "total_settled_amount": total_settled_amount,
                "hospitals_count": hospitals_count,
            }
        )

    return render_template("claims/dashboard.html", **context)


@claims_bp.route("/policies")
@login_required
def my_policies():
    user = get_current_user()
    if user.role != "policyholder":
        flash("Policy view is reserved for policyholders.", "warning")
        return redirect(url_for("claims.dashboard"))

    policies = Policy.query.filter_by(holder_user_id=user.id).all()
    policy_data = []
    for pol in policies:
        rem_cover = get_remaining_cover(pol)
        prior_paid = get_prior_paid_payouts(pol.id)
        policy_data.append({"policy": pol, "remaining_cover": rem_cover, "prior_paid": prior_paid})

    return render_template("claims/my_policies.html", policies=policy_data, user=user)


@claims_bp.route("/claims")
@login_required
def claim_list():
    user = get_current_user()
    query = Claim.query

    # Role-based scoping
    if user.role == "policyholder":
        user_policy_ids = [p.id for p in Policy.query.filter_by(holder_user_id=user.id).all()]
        query = query.filter(Claim.policy_id.in_(user_policy_ids)) if user_policy_ids else query.filter(Claim.id == -1)
    elif user.role == "hospital":
        if not user.hospital_id:
            query = query.filter(Claim.id == -1)
        else:
            query = query.filter(Claim.hospital_id == user.hospital_id, Claim.claim_type == "cashless")

    # Search filter (Claim ID or Member Name)
    q = request.args.get("q", "").strip()
    if q:
        if q.isdigit():
            query = query.filter(or_(Claim.id == int(q), Claim.member.has(Member.display_name.ilike(f"%{q}%"))))
        else:
            query = query.filter(Claim.member.has(Member.display_name.ilike(f"%{q}%")))

    # Policy ID filter (accepts "101" or "POL-101"); combined with the role scoping
    # above, so a hospital desk only ever sees that policy's claims at its own hospital.
    policy_id = request.args.get("policy_id", "").strip().upper().replace("POL-", "")
    if policy_id:
        query = query.filter(Claim.policy_id == int(policy_id)) if policy_id.isdigit() else query.filter(Claim.id == -1)

    # Status filter
    status = request.args.get("status", "").strip()
    if status:
        query = query.filter(Claim.status == status)

    # Claim type filter
    claim_type = request.args.get("claim_type", "").strip()
    if claim_type:
        query = query.filter(Claim.claim_type == claim_type)

    # Hospital filter
    hospital_id = request.args.get("hospital_id", "").strip()
    if hospital_id and hospital_id.isdigit():
        query = query.filter(Claim.hospital_id == int(hospital_id))

    claims = query.order_by(Claim.created_at.desc()).all()
    hospitals = Hospital.query.order_by(Hospital.name).all()

    return render_template(
        "claims/claim_list.html",
        claims=claims,
        hospitals=hospitals,
        filters={
            "q": q,
            "status": status,
            "claim_type": claim_type,
            "hospital_id": hospital_id,
            "policy_id": request.args.get("policy_id", "").strip(),
        },
    )


@claims_bp.route("/claims/new", methods=["GET", "POST"])
@login_required
def create_claim():
    user = get_current_user()
    if user.role not in ("policyholder", "hospital"):
        flash("Only policyholders and hospital desks can create claims.", "danger")
        return redirect(url_for("claims.dashboard"))

    if request.method == "POST":
        action = request.form.get("action", "draft")  # 'draft' or 'submit'
        is_submit = action == "submit"

        policy_id = request.form.get("policy_id", type=int)
        member_id = request.form.get("member_id", type=int)
        treatment_type = request.form.get("treatment_type", "").strip()
        admission_date_str = request.form.get("admission_date", "").strip()
        discharge_date_str = request.form.get("discharge_date", "").strip()
        requested_amount_str = request.form.get("requested_amount", "").strip()
        description = request.form.get("description", "").strip()

        # Determine claim type and hospital
        if user.role == "hospital":
            claim_type = "cashless"
            hospital_id = user.hospital_id
        else:
            claim_type = "reimbursement"
            hospital_id = request.form.get("hospital_id", type=int)

        # Parse dates and amount
        try:
            admission_date = datetime.datetime.strptime(admission_date_str, "%Y-%m-%d").date()
            discharge_date = datetime.datetime.strptime(discharge_date_str, "%Y-%m-%d").date()
            requested_amount = Decimal(requested_amount_str)
        except (ValueError, TypeError):
            flash("Invalid date or monetary amount format.", "danger")
            return redirect(url_for("claims.create_claim"))

        policy = Policy.query.get(policy_id)
        member = Member.query.get(member_id)
        hospital = Hospital.query.get(hospital_id)

        if not policy or not member or not hospital:
            flash("Invalid policy, member, or hospital selection.", "danger")
            return redirect(url_for("claims.create_claim"))

        # Validate business rules
        valid, errors = validate_claim_data(
            policy=policy,
            member=member,
            hospital=hospital,
            user=user,
            claim_type=claim_type,
            treatment_type=treatment_type,
            admission_date=admission_date,
            discharge_date=discharge_date,
            requested_amount=requested_amount,
            is_submission=is_submit,
        )

        # Hospital bill + discharge summary uploads: both are mandatory to submit,
        # optional while saving a draft (can be added later from the claim page).
        upload_errors = validate_uploads_from_request(request.files, require_all=is_submit)
        if upload_errors:
            valid = False
            errors = list(errors) + upload_errors

        if not valid:
            for err in errors:
                flash(err, "danger")
            return redirect(url_for("claims.create_claim"))

        # Create claim record
        status = "submitted" if is_submit else "draft"
        claim = Claim(
            policy_id=policy.id,
            member_id=member.id,
            hospital_id=hospital.id,
            claim_type=claim_type,
            treatment_type=treatment_type,
            admission_date=admission_date,
            discharge_date=discharge_date,
            requested_amount_inr=requested_amount,
            status=status,
        )
        db.session.add(claim)
        db.session.flush()

        # Create the document checklist and store any uploaded files
        apply_uploads(claim, request.files)

        # Record audit history event
        note = description or (f"Claim {status} by {user.display_name}")
        record_history_event(
            claim=claim,
            from_status=None,
            to_status=status,
            actor_user_id=user.id,
            note=note,
        )

        db.session.commit()
        flash(f"Claim #{claim.id} created successfully as {status.upper()}.", "success")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    # GET request - load forms
    if user.role == "policyholder":
        policies = Policy.query.filter_by(holder_user_id=user.id, status="active").all()
        hospitals = Hospital.query.order_by(Hospital.name).all()
        default_hospital = None
    else:
        # Hospital desk looks a policy up by the ID the patient brings (no list of all policies)
        policies = []
        hospitals = Hospital.query.filter_by(id=user.hospital_id).all()
        default_hospital = hospitals[0] if hospitals else None

    return render_template(
        "claims/create_claim.html",
        user=user,
        policies=policies,
        hospitals=hospitals,
        default_hospital=default_hospital,
        today=datetime.date.today(),
    )


@claims_bp.route("/claims/<int:claim_id>")
@login_required
def claim_detail(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    # Authorization Check
    if user.role == "policyholder" and claim.policy.holder_user_id != user.id:
        abort(403)
    elif user.role == "hospital" and (claim.hospital_id != user.hospital_id or claim.claim_type != "cashless"):
        abort(403)

    # Check for potential duplicates
    duplicates = check_potential_duplicates(
        member_id=claim.member_id,
        hospital_id=claim.hospital_id,
        admission_date=claim.admission_date,
        discharge_date=claim.discharge_date,
        claim_type=claim.claim_type,
        exclude_claim_id=claim.id,
    )

    # Calculate remaining cover
    remaining_cover = get_remaining_cover(claim.policy, exclude_claim_id=claim.id)

    # Calculation breakdown if eligible amount is present
    breakdown = None
    if claim.eligible_amount_inr is not None:
        breakdown = get_calculation_breakdown(
            requested_amount=claim.requested_amount_inr,
            eligible_amount=claim.eligible_amount_inr,
            deductible=claim.policy.plan.deductible_inr,
            copay_percent=claim.policy.plan.copay_percent,
        )

    return render_template(
        "claims/claim_detail.html",
        claim=claim,
        duplicates=duplicates,
        remaining_cover=remaining_cover,
        breakdown=breakdown,
    )


@claims_bp.route("/claims/<int:claim_id>/submit", methods=["POST"])
@login_required
def submit_draft(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    # Only creator can submit draft
    if claim.status != "draft":
        flash("Only draft claims can be submitted.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    if user.role == "policyholder" and claim.policy.holder_user_id != user.id:
        abort(403)
    if user.role == "hospital" and claim.hospital_id != user.hospital_id:
        abort(403)

    valid, errors = validate_claim_data(
        policy=claim.policy,
        member=claim.member,
        hospital=claim.hospital,
        user=user,
        claim_type=claim.claim_type,
        treatment_type=claim.treatment_type,
        admission_date=claim.admission_date,
        discharge_date=claim.discharge_date,
        requested_amount=claim.requested_amount_inr,
        is_submission=True,
    )

    if not valid:
        for err in errors:
            flash(err, "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    # Hospital bill and discharge summary must both be uploaded before submission
    missing = missing_documents(claim)
    if missing:
        flash("Upload the required documents before submitting: " + ", ".join(missing) + ".", "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    claim.status = "submitted"
    record_history_event(
        claim=claim,
        from_status="draft",
        to_status="submitted",
        actor_user_id=user.id,
        note="Claim submitted for insurance evaluation.",
    )
    db.session.commit()
    flash(f"Claim #{claim.id} submitted successfully.", "success")
    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


def _authorize_claim_access(user, claim, submitter_only: bool = False) -> None:
    """Abort 403 unless the user may see (or, if submitter_only, edit) this claim."""
    if user.role == "policyholder" and claim.policy.holder_user_id != user.id:
        abort(403)
    if user.role == "hospital" and (claim.hospital_id != user.hospital_id or claim.claim_type != "cashless"):
        abort(403)
    if submitter_only and user.role not in ("policyholder", "hospital"):
        abort(403)


@claims_bp.route("/claims/<int:claim_id>/documents", methods=["POST"])
@login_required
def upload_documents(claim_id: int):
    """Upload (or replace) the hospital bill / discharge summary on a draft claim."""
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)
    _authorize_claim_access(user, claim, submitter_only=True)

    if claim.status != "draft":
        flash("Documents can only be changed while the claim is a draft or awaiting more information.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    errors = validate_uploads_from_request(request.files, require_all=False)
    if errors:
        for err in errors:
            flash(err, "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    saved = apply_uploads(claim, request.files)
    if not saved:
        flash("Choose at least one file to upload.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    db.session.commit()
    flash(f"{saved} document(s) uploaded.", "success")
    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


@claims_bp.route("/claims/documents/<int:doc_id>/download")
@login_required
def download_document(doc_id: int):
    user = get_current_user()
    doc = ClaimDocument.query.get_or_404(doc_id)
    claim = doc.claim
    _authorize_claim_access(user, claim)
    if not doc.has_file:
        abort(404)
    folder = os.path.join(current_app.config["UPLOAD_FOLDER"], f"claim_{claim.id}")
    return send_from_directory(
        folder,
        doc.stored_filename,
        download_name=doc.original_filename or doc.stored_filename,
        as_attachment=request.args.get("download") == "1",
    )


@claims_bp.route("/claims/<int:claim_id>/respond", methods=["POST"])
@login_required
def respond_more_info(claim_id: int):
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    if claim.status != "more_info":
        flash("This claim is not awaiting more information.", "warning")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    if user.role == "policyholder" and claim.policy.holder_user_id != user.id:
        abort(403)
    if user.role == "hospital" and claim.hospital_id != user.hospital_id:
        abort(403)

    response_note = request.form.get("response_note", "").strip()
    if not response_note:
        flash("Please provide a response explanation.", "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))

    # Validate and store newly uploaded documents; both must be on file to resubmit
    upload_errors = validate_uploads_from_request(request.files, require_all=True, existing=claim.documents)
    if upload_errors:
        for err in upload_errors:
            flash(err, "danger")
        return redirect(url_for("claims.claim_detail", claim_id=claim.id))
    uploaded = apply_uploads(claim, request.files)

    claim.status = "submitted"
    record_history_event(
        claim=claim,
        from_status="more_info",
        to_status="submitted",
        actor_user_id=user.id,
        note=f"Information submitted by {user.display_name}: {response_note}"
             + (f" ({uploaded} document(s) uploaded)" if uploaded else ""),
    )
    db.session.commit()
    flash(f"Response recorded for Claim #{claim.id}. It is now back in the claims queue.", "success")
    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


@claims_bp.route("/api/policies/<int:policy_id>/members")
@login_required
def api_policy_members(policy_id: int):
    policy = Policy.query.get_or_404(policy_id)
    members_data = [
        {"id": m.id, "display_name": m.display_name, "relationship": m.relationship}
        for m in policy.members
    ]
    # A hospital desk also gets this policy's earlier visits at ITS OWN hospital only
    previous_visits = []
    user = get_current_user()
    if user.role == "hospital" and user.hospital_id:
        visits = (
            Claim.query.filter_by(policy_id=policy.id, hospital_id=user.hospital_id, claim_type="cashless")
            .order_by(Claim.admission_date.desc())
            .all()
        )
        previous_visits = [
            {
                "claim_id": c.id,
                "member": c.member.display_name,
                "admission_date": c.admission_date.isoformat(),
                "discharge_date": c.discharge_date.isoformat(),
                "status": c.status,
                "url": url_for("claims.claim_detail", claim_id=c.id),
            }
            for c in visits
        ]
    return jsonify({
        "policy_id": policy.id,
        "previous_visits": previous_visits,
        "plan_name": policy.plan.name,
        "covered_treatment_types": policy.plan.covered_treatment_types,
        "status": policy.status,
        "start_date": policy.start_date.isoformat(),
        "end_date": policy.end_date.isoformat(),
        "is_active_today": policy.is_active_on(datetime.date.today()),
        "members": members_data
    })
