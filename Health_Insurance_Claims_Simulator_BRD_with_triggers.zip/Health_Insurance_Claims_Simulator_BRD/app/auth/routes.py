from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

from app.auth.decorators import login_required
from app.models import User

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("claims.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password_hash, password):
            session.clear()
            session["user_id"] = user.id
            session["username"] = user.username
            session["display_name"] = user.display_name
            session["user_role"] = user.role
            session["hospital_id"] = user.hospital_id

            flash(f"Welcome back, {user.display_name} ({user.role.replace('_', ' ').title()})!", "success")
            next_url = request.args.get("next")
            return redirect(next_url or url_for("claims.dashboard"))
        else:
            flash("Invalid username or password. Please verify your credentials.", "danger")

    return render_template("auth/login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out successfully.", "info")
    return redirect(url_for("auth.login"))
