import functools
import secrets
from typing import Callable, Optional

from flask import abort, flash, redirect, request, session, url_for
from app.models import User


def get_current_user() -> Optional[User]:
    """Retrieve currently authenticated User model instance from session."""
    user_id = session.get("user_id")
    if not user_id:
        return None
    from app.extensions import db
    return db.session.get(User, user_id)


def login_required(f: Callable) -> Callable:
    """Ensure user is logged in, otherwise redirect to login page."""
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to access this page.", "warning")
            return redirect(url_for("auth.login", next=request.url))
        return f(*args, **kwargs)
    return decorated_function


def role_required(*allowed_roles: str) -> Callable:
    """Ensure authenticated user possesses one of the allowed roles, otherwise 403 Forbidden."""
    def decorator(f: Callable) -> Callable:
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            if "user_id" not in session:
                flash("Please sign in to access this page.", "warning")
                return redirect(url_for("auth.login", next=request.url))
            
            user_role = session.get("user_role")
            if user_role not in allowed_roles:
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def generate_csrf_token() -> str:
    """Generate or retrieve per-session CSRF token."""
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(24)
    return session["csrf_token"]


def validate_csrf_token() -> None:
    """Validate CSRF token on POST requests."""
    from flask import current_app
    if current_app.config.get("TESTING") or not current_app.config.get("WTF_CSRF_ENABLED", True):
        return

    if request.method == "POST":
        token = request.form.get("csrf_token") or request.headers.get("X-CSRFToken")
        expected = session.get("csrf_token")
        if not expected or not token or token != expected:
            abort(400, description="Invalid or missing CSRF token.")
