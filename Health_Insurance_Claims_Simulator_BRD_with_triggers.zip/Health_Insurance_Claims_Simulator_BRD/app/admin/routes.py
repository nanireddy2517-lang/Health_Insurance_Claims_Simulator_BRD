import datetime
from decimal import Decimal
from flask import (
    Blueprint,
    abort,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)
from sqlalchemy import func

from app.auth.decorators import get_current_user, role_required
from app.extensions import db
from app.models import Claim, Hospital, Plan, Policy, Settlement, User
from app.services.calculator import calculate_payout
from app.services.rules import record_history_event

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/settlements")
@role_required("admin")
def settlements_list():
    """List claims awaiting settlement (approved) and historical settlements."""
    approved_claims = Claim.query.filter_by(status="approved").order_by(Claim.created_at.asc()).all()
    settled_claims = Claim.query.filter_by(status="paid").order_by(Claim.payment_recorded_date.desc()).all()

    return render_template(
        "admin/settlements.html",
        approved_claims=approved_claims,
        settled_claims=settled_claims,
    )


@admin_bp.route("/settlements/<int:claim_id>/pay", methods=["POST"])
@role_required("admin")
def record_settlement(claim_id: int):
    """
    FR07 Simulated Settlement:
    Administrator records payout for an approved claim.
    Payee type: 'hospital' for cashless, 'policyholder' for reimbursement.
    Payout formula strictly enforced.
    Atomic transaction.
    """
    user = get_current_user()
    claim = Claim.query.get_or_404(claim_id)

    if claim.status != "approved":
        flash("Settlements can only be recorded for APPROVED claims.", "danger")
        return redirect(url_for("admin.settlements_list"))

    if not claim.eligible_amount_inr or claim.eligible_amount_inr <= Decimal("0.00"):
        flash("Cannot settle claim without an approved eligible amount.", "danger")
        return redirect(url_for("admin.settlements_list"))

    # Compute payout
    plan = claim.policy.plan
    payout = calculate_payout(
        eligible_amount=claim.eligible_amount_inr,
        deductible=plan.deductible_inr,
        copay_percent=plan.copay_percent,
    )

    payee_type = "hospital" if claim.claim_type == "cashless" else "policyholder"
    today = datetime.date.today()

    try:
        # 1. Create Settlement record
        settlement = Settlement(
            claim_id=claim.id,
            payee_type=payee_type,
            amount_inr=payout,
            recorded_by_user_id=user.id,
            recorded_date=today,
        )
        db.session.add(settlement)

        # 2. Update claim status and payment date
        claim.status = "paid"
        claim.payment_recorded_date = today

        # 3. Add history event
        payee_name = claim.hospital.name if payee_type == "hospital" else claim.policy.holder.display_name
        record_history_event(
            claim=claim,
            from_status="approved",
            to_status="paid",
            actor_user_id=user.id,
            note=f"Simulated settlement of ₹{payout} recorded. Payee: {payee_name} ({payee_type}).",
            event_date=today,
        )

        db.session.commit()
        flash(f"Settlement of ₹{payout} recorded successfully for Claim #{claim.id} (Payee: {payee_type}).", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error processing settlement: {str(e)}", "danger")

    return redirect(url_for("claims.claim_detail", claim_id=claim.id))


@admin_bp.route("/reports")
@role_required("admin")
def reports():
    """
    FR10 Dashboards and Reports:
    Aggregated counts by status, by type, and monetary sums (requested, eligible, paid).
    """
    # Status counts
    status_counts_raw = db.session.query(Claim.status, func.count(Claim.id)).group_by(Claim.status).all()
    status_counts = {status: count for status, count in status_counts_raw}

    # Type counts
    type_counts_raw = db.session.query(Claim.claim_type, func.count(Claim.id)).group_by(Claim.claim_type).all()
    type_counts = {ctype: count for ctype, count in type_counts_raw}

    # Financial sums
    total_requested = db.session.query(func.coalesce(func.sum(Claim.requested_amount_inr), Decimal("0.00"))).scalar()
    total_eligible = db.session.query(
        func.coalesce(func.sum(Claim.eligible_amount_inr), Decimal("0.00"))
    ).filter(Claim.status.in_(["approved", "paid"])).scalar()
    total_settled = db.session.query(func.coalesce(func.sum(Settlement.amount_inr), Decimal("0.00"))).scalar()

    total_claims = Claim.query.count()

    return render_template(
        "admin/reports.html",
        status_counts=status_counts,
        type_counts=type_counts,
        total_requested=total_requested,
        total_eligible=total_eligible,
        total_settled=total_settled,
        total_claims=total_claims,
    )


@admin_bp.route("/reference")
@role_required("admin")
def reference_data():
    """Manage reference data (hospitals, plans)."""
    hospitals = Hospital.query.order_by(Hospital.name).all()
    plans = Plan.query.order_by(Plan.id).all()

    return render_template(
        "admin/reference.html",
        hospitals=hospitals,
        plans=plans,
    )


@admin_bp.route("/hospital/<int:hospital_id>/toggle-network", methods=["POST"])
@role_required("admin")
def toggle_network(hospital_id: int):
    """Toggle network eligibility for a hospital."""
    hospital = Hospital.query.get_or_404(hospital_id)
    hospital.network_status = not hospital.network_status
    db.session.commit()
    status_text = "Network Hospital" if hospital.network_status else "Non-Network Hospital"
    flash(f"Updated {hospital.name} to {status_text}.", "info")
    return redirect(url_for("admin.reference_data"))
