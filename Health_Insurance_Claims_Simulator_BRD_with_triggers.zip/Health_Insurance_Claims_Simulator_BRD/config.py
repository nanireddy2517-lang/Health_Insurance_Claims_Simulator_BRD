import os
from dotenv import load_dotenv
from sqlalchemy.engine import URL

load_dotenv()

class Config:
    """Configuration exclusively for MySQL 8.0 Database Server."""
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-health-claims-sim-2026")

    # MySQL connection parameters
    DB_USER = os.environ.get("DB_USER", "root")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "Nani2005")
    DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
    DB_PORT = os.environ.get("DB_PORT", "3306")
    DB_NAME = os.environ.get("DB_NAME", "health_claims_simulator")

    # Build MySQL SQLAlchemy URL using URL.create to properly handle
    # special characters (like '@', '#', ':') in the password
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL",
        URL.create(
            "mysql+pymysql",
            username=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=int(DB_PORT),
            database=DB_NAME,
            query={"charset": "utf8mb4"},
        )
    )

    # Claim document uploads (hospital bill, discharge summary)
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", os.path.join(BASE_DIR, "uploads"))
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB per request
    ALLOWED_UPLOAD_EXTENSIONS = {"pdf", "jpg", "jpeg", "png"}

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_recycle": 280,
        "pool_pre_ping": True,
    }
