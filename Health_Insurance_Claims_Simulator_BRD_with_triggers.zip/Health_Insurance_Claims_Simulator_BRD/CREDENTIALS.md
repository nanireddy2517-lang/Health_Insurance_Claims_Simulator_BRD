# Health Insurance Claims Simulator - Login Credentials

**Password for ALL accounts: `password123`**

| Role           | Username        | Password      | Name              |
|----------------|-----------------|---------------|-------------------|
| Policyholder   | aasha           | password123   | Aasha Rao         |
| Policyholder   | bilal           | password123   | Bilal Khan        |
| Policyholder   | chitra          | password123   | Chitra Devi       |
| Policyholder   | dev             | password123   | Dev Kumar         |
| Hospital       | city_hospital   | password123   | CityCare Desk     |
| Hospital       | lotus_hospital  | password123   | Lotus Desk        |
| Claims Officer | officer_meera   | password123   | Meera Shah        |
| Claims Officer | officer_rahul   | password123   | Rahul Sen         |
| Admin          | admin_demo      | password123   | Demo Administrator|

## Setup
1. Edit `config.py` (or create a `.env`) and set `DB_PASSWORD` to your MySQL root password.
2. Import `complete_practice_dataset.sql` into MySQL (the password hashes in it are fixed).
3. If you already imported the old SQL, run `python reset_passwords.py` instead.
4. Start the Flask app and log in with any account above.

Note: users 5-8 (esha, farhan, gita, harish), green_hospital and sunrise_hospital appear
in the CSV dataset only, not in the SQL seed. `reset_passwords.py` covers any users in the table.

## Still can't log in?
Run `python diagnose_login.py` - it shows which database you are connected to, lists the
users, tests bilal/password123, and fixes the hashes automatically.
